﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace P8
{
    public partial class frmExe5 : Form
    {
        public frmExe5()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string[] correctAnswers = { "A", "A", "E", "C", "B", "B", "D", "A", "B", "E" };
            ArrayList output = new ArrayList();
            char[,] studentsAnswers = new char[2, correctAnswers.Length];

            for (int i = 0; i < studentsAnswers.GetLength(0); i++)
            {
                for (int j = 0; j < studentsAnswers.GetLength(1); j++)
                {
                    if(char.TryParse(Interaction.InputBox($"Insira a resposta {j + 1} do aluno {i + 1}.", "Inserção de respostas"), out studentsAnswers[i, j]) && (((int)studentsAnswers[i, j] >= (int)'A' && (int)studentsAnswers[i, j] <= (int)'E') || ((int)studentsAnswers[i, j] >= (int)'a' && (int)studentsAnswers[i, j] <= (int)'e')))
                    {
                        if (studentsAnswers[i, j].ToString().ToUpper() == correctAnswers[j])
                        {
                            output.Add($"O aluno {i + 1} acertou a questão {j + 1}. Marcou {studentsAnswers[i, j].ToString().ToUpper()}.");
                        }
                        else
                        {
                            output.Add($"O aluno {i + 1} errou a questão {j + 1}. Marcou {studentsAnswers[i, j].ToString().ToUpper()} e era {correctAnswers[j]}.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida. Insira um caracter de A a E.");
                        j--;
                    }
                }
            }

            lbxOutput.Items.AddRange(output.ToArray());
        }
    }
}
