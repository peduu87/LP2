﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace P8
{
    public partial class frmExe2 : Form
    {
        public frmExe2()
        {
            InitializeComponent();
        }

        private void frmExe2_Load(object sender, EventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            ArrayList names = new ArrayList();

            names.Add("Ana");
            names.Add("André");
            names.Add("Débora");
            names.Add("Fátima");
            names.Add("João");
            names.Add("Janete");
            names.Add("Otávio");
            names.Add("Marcelo");
            names.Add("Pedro");
            names.Add("Thais");
            names.Remove("Otávio"); // Coitado.

            lbxOutput.Items.AddRange(names.ToArray());
        }

        private void lbxOutput_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
