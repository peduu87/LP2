﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P8
{
    public partial class frmExe1 : Form
    {
        public frmExe1()
        {
            InitializeComponent();
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            string[] intsToString = new string[20];
            int aux;

            for (int i = 0; i < intsToString.Length; i++)
            {
                if (int.TryParse(Interaction.InputBox($"Insira um número inteiro (index {i + 1}).", "Inserção"), out aux))
                {
                    intsToString[19 - i] = aux.ToString();
                }
                else
                {
                    MessageBox.Show("Valor inválido.");
                    i--;
                }
            }

            lbxOutput.Items.AddRange(intsToString);
        }
    }
}
