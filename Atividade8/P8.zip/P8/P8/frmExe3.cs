﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P8
{
    public partial class frmExe3 : Form
    {
        public frmExe3()
        {
            InitializeComponent();
        }

        private void frmExe3_Load(object sender, EventArgs e)
        {

        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            double[,] studentsGrades = new double[20, 3];
            double[] studentsFinalGrade = new double[20];
            string output = string.Empty;

            int i = 0, j = 0;

            for(i = 0; i < studentsGrades.GetLength(0); i++)
            {
                for(j = 0; j <  studentsGrades.GetLength(1); j++)
                {
                    if (Double.TryParse(Interaction.InputBox($"Insira a nota {j + 1} do aluno {i + 1}.", "Inserção de notas"), out studentsGrades[i, j]) && studentsGrades[i, j] >= 0)
                    {
                        studentsFinalGrade[i] += studentsGrades[i, j];
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }
                }
                studentsFinalGrade[i] /= 3;
                studentsFinalGrade[i] = Math.Round(studentsFinalGrade[i] * 10) / 10;
                output += "Média aluno " + (i + 1) + ": " + studentsFinalGrade[i] + "\n";
            }

            MessageBox.Show(output);
        }
    }
}
