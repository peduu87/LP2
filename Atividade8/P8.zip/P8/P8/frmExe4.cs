﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P8
{
    public partial class frmExe4 : Form
    {
        public frmExe4()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string[] names = new string[10], output = new string[names.Length];
            int[] charCount = new int[names.Length];

            for (int i = 0; i < names.Length; i++)
            {
                names[i] = Interaction.InputBox($"Insira o nome {i + 1}.", "Inserção de nomes");

                if (names[i].Replace(" ", "") == string.Empty)
                {
                    MessageBox.Show("Nome inválido.");
                    i--;
                }
                else
                {
                    charCount[i] = names[i].Replace(" ", "").Length;

                    output[i] = $"O nome {names[i]} tem {charCount[i]} caracteres.";
                }
            }

            lbxOutput.Items.AddRange(output);
        }
    }
}
