﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            double valA = 0, valB = 0, valC = 0;

            if (!Double.TryParse(txtbxValA.Text, out valA) && valA < 0)
            {
                errorProviderA.SetError(txtbxValA, "Valor inválido.");
                txtbxValA.Focus();
            }
            else if (!Double.TryParse(txtbxValB.Text, out valB) && valB < 0)
            {
                errorProviderA.Clear();
                errorProviderB.SetError(txtbxValB, "Valor inválido.");
                txtbxValB.Focus();
            }
            else if (!Double.TryParse(txtbxValC.Text, out valC) && valC < 0)
            {
                errorProviderB.Clear();
                errorProviderC.SetError(txtbxValC, "Valor inválido.");
                txtbxValC.Focus();
            }
            else if ((valA > Math.Abs(valB - valC) && valA < valB + valC) && (valB > Math.Abs(valA - valC) && valB < valA + valC) && (valC > Math.Abs(valA - valB) && valC < valA + valB));
            {
                errorProviderA.Clear(); errorProviderB.Clear(); errorProviderC.Clear();

                if (valA == valB && valB == valC)
                {
                    MessageBox.Show("Triângulo equilátero.");
                }
                else if (valA != valB && valB != valC && valC != valA)
                {
                    MessageBox.Show("Triângulo escaleno.");
                }
                else
                {
                    MessageBox.Show("Triângulo isóceles.");
                }
            }
            
        }
    }
}
