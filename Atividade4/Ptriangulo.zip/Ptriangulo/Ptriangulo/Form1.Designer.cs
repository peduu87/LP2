﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtbxValA = new System.Windows.Forms.TextBox();
            this.lblValA = new System.Windows.Forms.Label();
            this.lblValB = new System.Windows.Forms.Label();
            this.lblValC = new System.Windows.Forms.Label();
            this.txtbxValB = new System.Windows.Forms.TextBox();
            this.txtbxValC = new System.Windows.Forms.TextBox();
            this.btnExecuta = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.errorProviderA = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderC = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderC)).BeginInit();
            this.SuspendLayout();
            // 
            // txtbxValA
            // 
            this.txtbxValA.Location = new System.Drawing.Point(231, 71);
            this.txtbxValA.Name = "txtbxValA";
            this.txtbxValA.Size = new System.Drawing.Size(226, 39);
            this.txtbxValA.TabIndex = 0;
            // 
            // lblValA
            // 
            this.lblValA.AutoSize = true;
            this.lblValA.Location = new System.Drawing.Point(55, 71);
            this.lblValA.Name = "lblValA";
            this.lblValA.Size = new System.Drawing.Size(146, 32);
            this.lblValA.TabIndex = 1;
            this.lblValA.Text = "Valor de A";
            // 
            // lblValB
            // 
            this.lblValB.AutoSize = true;
            this.lblValB.Location = new System.Drawing.Point(55, 128);
            this.lblValB.Name = "lblValB";
            this.lblValB.Size = new System.Drawing.Size(146, 32);
            this.lblValB.TabIndex = 2;
            this.lblValB.Text = "Valor de B";
            // 
            // lblValC
            // 
            this.lblValC.AutoSize = true;
            this.lblValC.Location = new System.Drawing.Point(55, 185);
            this.lblValC.Name = "lblValC";
            this.lblValC.Size = new System.Drawing.Size(147, 32);
            this.lblValC.TabIndex = 3;
            this.lblValC.Text = "Valor de C";
            // 
            // txtbxValB
            // 
            this.txtbxValB.Location = new System.Drawing.Point(231, 128);
            this.txtbxValB.Name = "txtbxValB";
            this.txtbxValB.Size = new System.Drawing.Size(226, 39);
            this.txtbxValB.TabIndex = 4;
            // 
            // txtbxValC
            // 
            this.txtbxValC.Location = new System.Drawing.Point(231, 185);
            this.txtbxValC.Name = "txtbxValC";
            this.txtbxValC.Size = new System.Drawing.Size(226, 39);
            this.txtbxValC.TabIndex = 5;
            // 
            // btnExecuta
            // 
            this.btnExecuta.AutoSize = true;
            this.btnExecuta.Location = new System.Drawing.Point(61, 435);
            this.btnExecuta.Name = "btnExecuta";
            this.btnExecuta.Size = new System.Drawing.Size(127, 42);
            this.btnExecuta.TabIndex = 6;
            this.btnExecuta.Text = "Executa";
            this.btnExecuta.UseVisualStyleBackColor = true;
            this.btnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // btnSair
            // 
            this.btnSair.AutoSize = true;
            this.btnSair.Location = new System.Drawing.Point(231, 435);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(120, 42);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // errorProviderA
            // 
            this.errorProviderA.ContainerControl = this;
            // 
            // errorProviderB
            // 
            this.errorProviderB.ContainerControl = this;
            // 
            // errorProviderC
            // 
            this.errorProviderC.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 604);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExecuta);
            this.Controls.Add(this.txtbxValC);
            this.Controls.Add(this.txtbxValB);
            this.Controls.Add(this.lblValC);
            this.Controls.Add(this.lblValB);
            this.Controls.Add(this.lblValA);
            this.Controls.Add(this.txtbxValA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbxValA;
        private System.Windows.Forms.Label lblValA;
        private System.Windows.Forms.Label lblValB;
        private System.Windows.Forms.Label lblValC;
        private System.Windows.Forms.TextBox txtbxValB;
        private System.Windows.Forms.TextBox txtbxValC;
        private System.Windows.Forms.Button btnExecuta;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.ErrorProvider errorProviderA;
        private System.Windows.Forms.ErrorProvider errorProviderB;
        private System.Windows.Forms.ErrorProvider errorProviderC;
    }
}

