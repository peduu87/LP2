﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnLetras = new System.Windows.Forms.Button();
            this.btnPrimeiroEspaco = new System.Windows.Forms.Button();
            this.btnNumeros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(204, 95);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(389, 175);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnLetras
            // 
            this.btnLetras.AutoSize = true;
            this.btnLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetras.Location = new System.Drawing.Point(266, 391);
            this.btnLetras.Name = "btnLetras";
            this.btnLetras.Size = new System.Drawing.Size(253, 34);
            this.btnLetras.TabIndex = 7;
            this.btnLetras.Text = "Contar letras";
            this.btnLetras.UseVisualStyleBackColor = true;
            // 
            // btnPrimeiroEspaco
            // 
            this.btnPrimeiroEspaco.AutoSize = true;
            this.btnPrimeiroEspaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrimeiroEspaco.Location = new System.Drawing.Point(266, 344);
            this.btnPrimeiroEspaco.Name = "btnPrimeiroEspaco";
            this.btnPrimeiroEspaco.Size = new System.Drawing.Size(253, 34);
            this.btnPrimeiroEspaco.TabIndex = 6;
            this.btnPrimeiroEspaco.Text = "Primeiro espaço em branco";
            this.btnPrimeiroEspaco.UseVisualStyleBackColor = true;
            // 
            // btnNumeros
            // 
            this.btnNumeros.AutoSize = true;
            this.btnNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumeros.Location = new System.Drawing.Point(266, 297);
            this.btnNumeros.Name = "btnNumeros";
            this.btnNumeros.Size = new System.Drawing.Size(253, 34);
            this.btnNumeros.TabIndex = 5;
            this.btnNumeros.Text = "Contar números";
            this.btnNumeros.UseVisualStyleBackColor = true;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLetras);
            this.Controls.Add(this.btnPrimeiroEspaco);
            this.Controls.Add(this.btnNumeros);
            this.Controls.Add(this.richTextBox1);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnLetras;
        private System.Windows.Forms.Button btnPrimeiroEspaco;
        private System.Windows.Forms.Button btnNumeros;
    }
}