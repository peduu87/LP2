﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtbx1.Text, txtbx2.Text) == 0)
            {
                MessageBox.Show("Os textos são iguais.");
            }
            else
            {
                MessageBox.Show("Os textos não são iguais.");
            }
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            String texto1 = txtbx1.Text;
            String texto2 = txtbx2.Text;
            int tamTexto2 = txtbx2.Text.Length; 
            String resultado;

            resultado = texto2.Substring(0, tamTexto2 / 2) + texto1 + texto2.Substring(tamTexto2 / 2, tamTexto2 / 2);

            txtbx2.Text = resultado;
        }

        private void btnAsteriscos_Click(object sender, EventArgs e)
        {
            String texto1 = txtbx1.Text;
            txtbx2.Text = texto1.Substring(0, texto1.Length / 2) + "**" + texto1.Substring(texto1.Length / 2);
        }
    }
}
