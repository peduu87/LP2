﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numIni, numFin;

            if (int.TryParse(txtbx1.Text, out numIni))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(txtbx1, "Valor inválido.");
            }

            if (int.TryParse(txtbx2.Text, out numFin))
            {
                if (numFin > numIni)
                {
                    errorProvider2.Clear();

                    Random rndm = new Random();
                    int numero = rndm.Next(numIni, numFin);

                    MessageBox.Show(numero.ToString());
                }
                else
                {
                    errorProvider2.SetError(txtbx2, "O número deve ser maior que o primeiro.");
                }
            }
            else
            {
                errorProvider2.SetError(txtbx2, "Valor inválido.");
            }
        }
    }
}
