﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnOcorrencias_Click(object sender, EventArgs e)
        {
            String texto1 = txtbx1.Text;
            String texto2 = txtbx2.Text;
            txtbx2.Text = texto2.Replace(texto1, "");
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            String texto1 = txtbx1.Text;
            txtbx2.Text = new string(texto1.Reverse().ToArray());
        }
    }
}
