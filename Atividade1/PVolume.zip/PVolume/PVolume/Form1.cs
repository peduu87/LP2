﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String textRaio = textBoxRaio.Text;
            String textAltura = textBoxAltura.Text;
            double raio = Convert.ToDouble(textRaio);
            double altura = Convert.ToDouble(textAltura);
            double volume;
            const float pi = 3.14f;

            if (!string.IsNullOrWhiteSpace(textRaio) && !string.IsNullOrWhiteSpace(textAltura))
            {
                volume = pi * raio * raio * altura;
                textBoxVolume.Text = Convert.ToString(Math.Round(volume*100)/100);
            }
            else
            {
                MessageBox.Show("Insira o(s) valor(es) que falta(m).");
            }
        }
    }
}
