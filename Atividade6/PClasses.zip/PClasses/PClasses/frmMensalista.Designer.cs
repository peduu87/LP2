﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbxMatricula = new System.Windows.Forms.TextBox();
            this.txtbxNome = new System.Windows.Forms.TextBox();
            this.txtbxSalMensal = new System.Windows.Forms.TextBox();
            this.txtbxDataAdmis = new System.Windows.Forms.TextBox();
            this.btnInstMensalista = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(159, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matrícula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(159, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Data de admissão";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(159, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Salário mensal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(159, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nome";
            // 
            // txtbxMatricula
            // 
            this.txtbxMatricula.Location = new System.Drawing.Point(364, 63);
            this.txtbxMatricula.Name = "txtbxMatricula";
            this.txtbxMatricula.Size = new System.Drawing.Size(100, 29);
            this.txtbxMatricula.TabIndex = 4;
            // 
            // txtbxNome
            // 
            this.txtbxNome.Location = new System.Drawing.Point(364, 99);
            this.txtbxNome.Name = "txtbxNome";
            this.txtbxNome.Size = new System.Drawing.Size(419, 29);
            this.txtbxNome.TabIndex = 5;
            // 
            // txtbxSalMensal
            // 
            this.txtbxSalMensal.Location = new System.Drawing.Point(364, 136);
            this.txtbxSalMensal.Name = "txtbxSalMensal";
            this.txtbxSalMensal.Size = new System.Drawing.Size(159, 29);
            this.txtbxSalMensal.TabIndex = 6;
            // 
            // txtbxDataAdmis
            // 
            this.txtbxDataAdmis.Location = new System.Drawing.Point(364, 171);
            this.txtbxDataAdmis.Name = "txtbxDataAdmis";
            this.txtbxDataAdmis.Size = new System.Drawing.Size(118, 29);
            this.txtbxDataAdmis.TabIndex = 7;
            // 
            // btnInstMensalista
            // 
            this.btnInstMensalista.AutoSize = true;
            this.btnInstMensalista.Location = new System.Drawing.Point(183, 299);
            this.btnInstMensalista.Name = "btnInstMensalista";
            this.btnInstMensalista.Size = new System.Drawing.Size(192, 34);
            this.btnInstMensalista.TabIndex = 8;
            this.btnInstMensalista.Text = "Instanciar mensalista";
            this.btnInstMensalista.UseVisualStyleBackColor = true;
            this.btnInstMensalista.Click += new System.EventHandler(this.btnInstMensalista_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(414, 299);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(333, 34);
            this.button1.TabIndex = 9;
            this.button1.Text = "Instanciar mensalista com parâmetros";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(930, 380);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnInstMensalista);
            this.Controls.Add(this.txtbxDataAdmis);
            this.Controls.Add(this.txtbxSalMensal);
            this.Controls.Add(this.txtbxNome);
            this.Controls.Add(this.txtbxMatricula);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbxMatricula;
        private System.Windows.Forms.TextBox txtbxNome;
        private System.Windows.Forms.TextBox txtbxSalMensal;
        private System.Windows.Forms.TextBox txtbxDataAdmis;
        private System.Windows.Forms.Button btnInstMensalista;
        private System.Windows.Forms.Button button1;
    }
}