﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double number1;
        double number2;
        double result;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_validated(object sender, EventArgs e)
        {

        }

        private void number1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out number1))
            {
                errorProvider1.SetError(txtNum1, "Valor inválido");
            }

            else
            {
                errorProvider1.SetError(txtNum1, "");
            }

        }


        private void number2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out number2))
            {
                errorProvider1.SetError(txtNum2, "Valor inválido");
            }

            else
            {
                errorProvider1.SetError(txtNum2, "");
            }
        }
        
        private void btnPlus_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out number1) || !Double.TryParse(txtNum2.Text, out number2))
            {
                txtNum1.Focus();
            }
            else
            {
                result = number1 + number2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out number1) || !Double.TryParse(txtNum2.Text, out number2))
            {
                txtNum1.Focus();
            }
            else
            {
                result = number1 - number2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out number1) || !Double.TryParse(txtNum2.Text, out number2))
            {
                txtNum1.Focus();
            }
            else
            {
                result = number1 * number2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            txtResult.Clear();

            if (!Double.TryParse(txtNum1.Text, out number1) || !Double.TryParse(txtNum2.Text, out number2))
            {
                txtNum1.Focus();
            }
            else if (number2 == 0)
            {
                errorProvider1.SetError(txtNum2, "Não exixte divisão por 0.");
            }
            else
            {
                result = number1 / number2;
                txtResult.Text = result.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja fechar a aplicação mesmo?", "Fechar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
