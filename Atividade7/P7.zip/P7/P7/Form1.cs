﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P7
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEx1 objEx1 = new frmEx1();
            objEx1.ShowDialog();
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEx2 objEx2 = new frmEx2();
            objEx2.ShowDialog();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEx3 objEx3 = new frmEx3();
            objEx3.ShowDialog();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEx4 objEx4 = new frmEx4();
            objEx4.ShowDialog();
        }
    }
}
