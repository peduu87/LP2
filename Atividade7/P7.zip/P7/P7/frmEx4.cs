﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P7
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            String txtProd = txtbxProd.Text;
            String txtSal = txtbxSal.Text;
            String txtGrat = txtbxGrat.Text;

            int prod;
            double sal, grat;

            if (!int.TryParse(txtProd, out prod) || prod < 0)
            {
                errProd.SetError(txtbxProd, "Insira um valor inteiro maior que 0.");
            }
            else
            {
                errProd.Clear();
            }

            if (!Double.TryParse(txtSal, out sal) || sal < 0)
            {
                errSal.SetError(txtbxSal, "Insira um valor real maior que 0.");
            }
            else
            {
                errSal.Clear();
            }

            if (!Double.TryParse(txtGrat, out grat) || grat < 0)
            {
                errGrat.SetError(txtbxGrat, "Insira um valor real maior que 0.");
            }
            else
            {
                errGrat.Clear();
            }

            if (prod > 0 && sal > 0 && grat >= 0)
            {
                double valA = 0;
                int valB = 0, valC = 0, valD = 0;

                valA = sal;

                if (prod >= 100)
                {
                    valB = 1;
                    if (prod >= 120)
                    {
                        valC = 1;
                        if (prod >= 150)
                        {
                            valD = 1;
                        }
                    }
                }

                double salBruto = valA + valA * (0.05 * valB + 0.1 * valC + 0.1 * valD) + grat;

                if (grat <= 0 && salBruto > 7000)
                {
                    salBruto = 7000;
                }

                MessageBox.Show($"{salBruto}");
            }
        }
    }
}
