﻿namespace P7
{
    partial class frmEx4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbxNome = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbxMatri = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbxProd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtbxSal = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbxGrat = new System.Windows.Forms.TextBox();
            this.errProd = new System.Windows.Forms.ErrorProvider(this.components);
            this.errSal = new System.Windows.Forms.ErrorProvider(this.components);
            this.errGrat = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errProd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errGrat)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(91, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 26);
            this.label2.TabIndex = 10;
            this.label2.Text = "Nome";
            // 
            // txtbxNome
            // 
            this.txtbxNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxNome.Location = new System.Drawing.Point(96, 66);
            this.txtbxNome.Name = "txtbxNome";
            this.txtbxNome.Size = new System.Drawing.Size(329, 29);
            this.txtbxNome.TabIndex = 9;
            // 
            // btnCalc
            // 
            this.btnCalc.AutoSize = true;
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(469, 223);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(195, 34);
            this.btnCalc.TabIndex = 8;
            this.btnCalc.Text = "Calcular salário bruto";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(91, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 26);
            this.label1.TabIndex = 12;
            this.label1.Text = "Matrícula";
            // 
            // txtbxMatri
            // 
            this.txtbxMatri.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxMatri.Location = new System.Drawing.Point(96, 142);
            this.txtbxMatri.Name = "txtbxMatri";
            this.txtbxMatri.Size = new System.Drawing.Size(206, 29);
            this.txtbxMatri.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(91, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 26);
            this.label3.TabIndex = 14;
            this.label3.Text = "Produção";
            // 
            // txtbxProd
            // 
            this.txtbxProd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxProd.Location = new System.Drawing.Point(96, 225);
            this.txtbxProd.Name = "txtbxProd";
            this.txtbxProd.Size = new System.Drawing.Size(123, 29);
            this.txtbxProd.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(91, 270);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 26);
            this.label4.TabIndex = 16;
            this.label4.Text = "Salário base";
            // 
            // txtbxSal
            // 
            this.txtbxSal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxSal.Location = new System.Drawing.Point(96, 299);
            this.txtbxSal.Name = "txtbxSal";
            this.txtbxSal.Size = new System.Drawing.Size(171, 29);
            this.txtbxSal.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(91, 352);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 26);
            this.label5.TabIndex = 18;
            this.label5.Text = "Gratificação";
            // 
            // txtbxGrat
            // 
            this.txtbxGrat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxGrat.Location = new System.Drawing.Point(96, 381);
            this.txtbxGrat.Name = "txtbxGrat";
            this.txtbxGrat.Size = new System.Drawing.Size(171, 29);
            this.txtbxGrat.TabIndex = 17;
            // 
            // errProd
            // 
            this.errProd.ContainerControl = this;
            // 
            // errSal
            // 
            this.errSal.ContainerControl = this;
            // 
            // errGrat
            // 
            this.errGrat.ContainerControl = this;
            // 
            // frmEx4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtbxGrat);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtbxSal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtbxProd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbxMatri);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtbxNome);
            this.Controls.Add(this.btnCalc);
            this.Name = "frmEx4";
            this.Text = "Exercício 4";
            ((System.ComponentModel.ISupportInitialize)(this.errProd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errSal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errGrat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbxNome;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbxMatri;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbxProd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbxSal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbxGrat;
        private System.Windows.Forms.ErrorProvider errProd;
        private System.Windows.Forms.ErrorProvider errSal;
        private System.Windows.Forms.ErrorProvider errGrat;
    }
}