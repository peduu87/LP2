﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P7
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }

        private void btnEspacos_Click(object sender, EventArgs e)
        {
            String txt = richTextBox1.Text;

            int i = 0, whiteSpaces = 0;

            while (i < txt.Length)
            {
                if (txt[i] == ' ')
                {
                    whiteSpaces++;
                }

                i++;
            }

            if (whiteSpaces > 0)
            {
                MessageBox.Show($"Há {whiteSpaces} espaço(s) em branco.");
            }
            else
            {
                MessageBox.Show("Não há espaços em branco.");
            }
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            String txt = richTextBox1.Text.ToLower();

            int rCounter = 0;

            foreach(char c in txt)
            {
                if (c == 'r')
                {
                    rCounter++;
                }
            }

            if (rCounter > 0)
            {
                MessageBox.Show($"Há {rCounter} 'R's.");
            }
            else
            {
                MessageBox.Show("Não há 'R's.");
            }
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            String txt = richTextBox1.Text.ToLower();

            int pairCounter = 0;
            
            for (int i = 0; i < txt.Length - 1; i++)
            {
                if (txt[i] == txt[i + 1])
                {
                    pairCounter++;
                }
            }

            if (pairCounter > 0)
            {
                MessageBox.Show($"Há {pairCounter} pares.");
            }
            else
            {
                MessageBox.Show("Não há pares.");
            }
        }
    }
}
