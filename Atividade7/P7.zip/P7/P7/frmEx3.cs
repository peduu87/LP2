﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P7
{
    public partial class frmEx3 : Form
    {
        public frmEx3()
        {
            InitializeComponent();
        }

        private void btnPalin_Click(object sender, EventArgs e)
        {
            String txt = richTextBox1.Text.Replace(" ", String.Empty).ToLower();
            String txtFirstHalf = txt.Substring(0, txt.Length / 2);
            String txtLastHalf;
            if (txt.Length % 2 == 0)
            {
                txtLastHalf = txt.Substring(txt.Length / 2);
            }
            else
            {
                txtLastHalf = txt.Substring(txt.Length / 2 + 1);
            }

            txtLastHalf = new string(txtLastHalf.ToCharArray().Reverse().ToArray());

            if (String.Compare(txtFirstHalf, txtLastHalf) == 0)
            {
                MessageBox.Show("É um palíndromo.");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo.");
            }
        }
    }
}
