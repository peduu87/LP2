﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double imc;

            double peso;
            if (!Double.TryParse(mskbxPeso.Text, out peso) || peso <= 0)
            {
                errorProvider.SetError(mskbxPeso, "Valor inválido.");
                mskbxPeso.Focus();
                txtbxImc.Clear();
            }
            else
            {
                errorProvider.SetError(mskbxPeso, "");
            }

            double altura;
            if (!Double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                errorProvider.SetError(mskbxAltura, "Valor inválido.");
                mskbxAltura.Focus();
                txtbxImc.Clear();
            }
            else
            {
                errorProvider.SetError(mskbxAltura, "");
            }

            if (peso != 0 && altura != 0)
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                
                if (imc < 18.5)
                {
                    txtbxImc.Text = "Magreza (" + imc + "kg/m2)";
                }
                else if (imc <= 24.9)
                {
                    txtbxImc.Text = "Normal (" + imc + "kg/m2)";
                }
                else if (imc <= 29.9)
                {
                    txtbxImc.Text = "Sobrepeso (" + imc + "kg/m2)";
                }
                else if (imc <= 39.9)
                {
                    txtbxImc.Text = "Obesidade (" + imc + "kg/m2)";
                }
                else
                {
                    txtbxImc.Text = "Obesidade grave (" + imc + "kg/m2)";
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtbxImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
